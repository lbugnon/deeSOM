from .sompy import SOMFactory
